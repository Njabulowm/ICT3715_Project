<?php
$title = "Lecturer Dashboard";
include('header.php');
?>
<!--banner-->	
<div class="banner">
<h2>
<a href="index.html">Home</a>
<i class="fa fa-angle-right"></i>
<span>Upload File</span>
</h2>
</div>
<!--//banner-->
<!--faq-->
<div class="blank">
<div class="blank-page">
<form method="POST" enctype="multipart/form-data" action="upload1.php">
<div class="form-group">
<label>Upload here</label>
<input name="file" type="file"  required="required" class="form-control"/>
<br/>
<input name="modCode" placeholder="Module Code" type="text"  required="required" class="form-control"/>
</div>
<button class="btn btn-primary" name="upload">Upload</button>
<br><br><br>
<div class="table-responsive">	
<table class="table table-bordered">
<thead class="alert-info">
<tr>
<th>File Name</th>
<th>File Type</th>
<th>Date Uploaded</th>
<th>File Path</th>
<th>Module Code</th>
</tr>
</thead>
<tbody>
<?php
require_once '../include/conn.php';
$sql = "SELECT * FROM `file`";
$query = $conn->prepare($sql);
$query->execute();

while($fetch = $query->fetch()){
?>

<tr>
<td><?php echo $fetch['file_name']?></td>
<td><?php echo $fetch['file_type']?></td>
<td><?php echo $fetch['date_uploaded']?></td>
<td><?php echo $fetch['location']?></td>
<td><?php echo $fetch['ModuleCode']?></td>
</tr>

<?php
}
?>
</tbody>
</table>
</div>
</div>
</div>

<!--//faq-->
<!---->

<?php
include('footer.php');
?>