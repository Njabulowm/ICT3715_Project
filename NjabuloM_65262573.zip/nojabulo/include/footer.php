<div class="copy-right">
	<p> &copy; 2022 OEP. All Rights Reserved | 
		Design by <a href="#">Nonjabulo</a> 
	</p>	    
</div>  
<!---->
<!--scrolling js-->
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!--//scrolling js-->
</body>
</html>