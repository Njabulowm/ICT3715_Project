<!DOCTYPE HTML>
<html>
<head>
	<title>Online Examination Portal | <?php echo $title;?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="" />
	<script type="application/x-javascript"> 
		addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); 
		function hideURLbar(){ window.scrollTo(0,1); } 
	</script>
	<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
	<!-- Custom Theme files -->
	<link href="css/style.css" rel='stylesheet' type='text/css' />
	<link href="css/font-awesome.css" rel="stylesheet"> 
	<script src="js/jquery.min.js"> </script>
	<script src="js/bootstrap.min.js"> </script>
</head>
<body>
	<div id='logo'>
		<p style="text-align: center;"><img src="images/logo.png" height="200px" alt="logo"/></p>
	</div>
