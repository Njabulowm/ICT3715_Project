<?php
$title = "Student Exam";
include('header.php');
?>
<!--banner-->	
<div class="banner">
<h2>
<a href="index.html">Home</a>
<i class="fa fa-angle-right"></i>
<span>View Exam</span>
</h2>
</div>
<!--//banner-->
<!--faq-->
<div class="blank">
<div class="blank-page">
<h2>View Today's Exams</h2>
<br>
<div id="container">
<table class="table table-bordered table-condensed">
<thead>
<tr>
<th>Module Code</th>
<th>Module Description</th>
<th>Take Exam</th>
</tr>
</thead>
<tbody>
<?php
$dateToday = date('Y-m-d');
//echo $dateToday;
//$selectQuery1 = "SELECT examsetup.ModuleCode, ModDesc 
//FROM examsetup, moduleinfo 
//WHERE examsetup.ModuleCode = moduleinfo.ModCode
//AND DateExam = $dateToday";
//$q = $conn->prepare($selectQuery1);
//$q->execute();
$stmt = $conn->prepare("SELECT examsetup.ModuleCode, ModDesc 
FROM examsetup, moduleinfo 
WHERE examsetup.ModuleCode = moduleinfo.ModCode
AND DateExam = '$dateToday'
ORDER BY ModuleCode");
$stmt->execute();
$modules = $stmt->fetchAll();
foreach($modules as $module)
{
?>
<tr>
<td>
<?php echo $module['ModuleCode']; ?>
</td>
<td>
<?php echo $module['ModDesc']; ?>
</td>
<td>
<a href="take_exam.php">Start Exam | <?php echo $module['ModuleCode']; ?></a>
</td>
<?php
}
?>
</tbody>
</table>
</div>

</div>
</div>

<!--//faq-->
<!---->

<?php
include('footer.php');
?>