<?php
		$title = "Landing Page";
		include('include/header.php');
?>

<div class="login">
		<div class="login-bottom">
			<h2 style="text-align: center;">Landing Page</h2>
			<div class="col-md-12 login-do">
				<a href="stud_login.php" class="hvr-shutter-in-horizontal">Student Login</a>
				<br>
				<a href="lect_login.php" class="hvr-shutter-in-horizontal">Lecturer Login</a>
				<br>
				<a href="examdep_login.php" class="hvr-shutter-in-horizontal">Exam Department Login</a>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
		<!---->

<?php
		include('include/footer.php');
?>