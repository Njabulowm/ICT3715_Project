<?php
$title = "Exam Department Dashboard";
include('header.php');
?>

<!--banner-->	
<div class="banner">
<h2>
<a href="index.html">Home</a>
<i class="fa fa-angle-right"></i>
<span>Dashboard</span>
</h2>
</div>
<!--//banner-->
<!--faq-->
<div class="blank">
<div class="blank-page">
Welcome <?php echo $_SESSION["staffname"]; ?>
</div>
</div>

<!--//faq-->
<!---->

<?php
include('footer.php');
?>